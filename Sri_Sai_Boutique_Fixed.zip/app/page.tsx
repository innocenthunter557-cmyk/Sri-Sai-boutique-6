export default function Home(){
return <main style={{padding:'2rem'}}><h1>Sri Sai Boutique</h1><p>Phone: +91 80747 23033</p></main>
}